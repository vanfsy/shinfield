<?php
/**
  * Get an key, secret key and associate ID by Amazon fill in this content.
  * save the file to app/Config/aws.php
  */
$config = array(
  'Aws' => array(
      'assoc' => 'ble-22',    // Your Amazon Associate ID
    'key' => 'AKIAJVPCEYESZQDE36WA',      // Your Amazon AWS Access Key ID
    'secret' => 'D8iPIcv8WlN3r6Tz4zDLa8Chaj08GfHT5OR7Wnsg'    // Your Amazon secret key for signature generation
  )
  );
?>