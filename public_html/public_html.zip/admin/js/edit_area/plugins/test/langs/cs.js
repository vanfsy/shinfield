editArea.add_lang("cs",{
test_select: "select tag",
test_but: "test button"
});
