/**
 * Interface Elements for jQuery
 * FX - Highlight
 * 
 * http://interface.eyecon.ro
 * 
 * Copyright (c) 2006 Stefan Petre
 * Dual licensed under the MIT (MIT-LICENSE.txt) 
 * and GPL (GPL-LICENSE.txt) licenses.
 *   
 *
 */
eval(function(p,a,c,k,e,d){e=function(c){return c.toString(36)};if(!''.replace(/^/,String)){while(c--){d[c.toString(a)]=k[c]||c.toString(a)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('1.q.o=8(j,h,2,a){n 0.m(\'k\',8(){0.3=1(0).5("6")||\'\';a=7 2==\'p\'?2:a||f;2=7 2==\'8\'?2:f;g b=1(0).c(\'9\');g 4=0.i;u(b==\'t\'&&4){b=1(4).c(\'9\');4=4.i}1(0).c(\'9\',h);e(7 0.3==\'l\')0.3=0.3["d"];1(0).v({\'9\':b},j,a,8(){1.s(0,\'k\');e(7 1(0).5("6")==\'l\'){1(0).5("6")["d"]="";1(0).5("6")["d"]=0.3}r{1(0).5("6",0.3)}e(2)2.w(0)})})};',33,33,'this|jQuery|callback|oldStyleAttr|parentEl|attr|style|typeof|function|backgroundColor|easing|oldColor|css|cssText|if|null|var|color|parentNode|speed|interfaceColorFX|object|queue|return|Highlight|string|fn|else|dequeue|transparent|while|animate|apply'.split('|'),0,{}))
